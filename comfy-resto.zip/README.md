# submission-dicoding-class-219

This is my submission for the "Menjadi Front-End Web Developer Expert" class from Dicoding

## Installation

Use [npm](https://nodejs.org/en/) to install dependencies

```bash
npm install
```

Start development server

```bash
npm run start-dev
```

## Build

Generate a full static production build

```bash
npm run build
```
